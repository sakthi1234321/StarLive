<?php
$con=new mysqli("localhost","hals","hals@123","halsandstarapp");
if($con->connect_error){
    echo"$con->connect_error";
    die("databe is not connected");
}
else {
    echo"database is connected";
}
?>